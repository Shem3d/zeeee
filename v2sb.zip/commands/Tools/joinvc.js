const { joinVoiceChannel } = require('@discordjs/voice');

module.exports = {
  name: 'joinvc',
  run: async (client, message, args, db) => {
    if (message.author.id !== client.user.id) return;
    const channelId = args[0];

    if (!channelId) {
      return message.edit(`\`❌\`*Veuillez spécifier un ID de canal vocal.*`);
    }

    const channel = client.channels.cache.get(channelId);
    if (!channel || !channel.isVoice()) {
      return message.edit(`\`❌\`*Le canal spécifié n\'est pas un canal vocal valide.*`);
    }

    try {
      const connection = joinVoiceChannel({
        channelId: channel.id,
        guildId: channel.guild.id,
        adapterCreator: channel.guild.voiceAdapterCreator,
        selfDeaf: db.mutecsq,
        selfMute: db.mute,
        clientId: client.user.id,
      });

      connection.on('ready', () => {
        message.edit(`\`✅\`*Je me suis connecté au canal vocal* \`${channel.name}\``);
      });

      connection.on('error', error => {
        console.error(`Impossible de rejoindre le canal vocal: ${error}`);
        message.edit(`\`❌\`*Je n\'ai pas pu rejoindre le canal vocal.*`);
      });
    } catch (error) {
      console.error(`Impossible de rejoindre le canal vocal: ${error}`);
      message.edit('*Je n\'ai pas pu rejoindre le canal vocal.*');
    }
  }
};