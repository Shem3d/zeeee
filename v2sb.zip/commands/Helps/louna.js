// command to get profile picture
const Discord = require("discord.js-selfbot-v13");
const {  language } = require("../../fonction")

module.exports = {
  name: "louna",
  description: "Louna SB Infos",
  run: async (client, message, args, db, prefix) => {

    message.edit(await language(client, `
⛧ __**Louna**__ ⛧
Pour tout probleme dm:
<@1138897889213562890>`))
  }
}; 