const Discord = require("discord.js-selfbot-v13");
const { language } = require("../../fonction");

module.exports = {
  name: "raid",
  description: "Menu Help",
  run: async (client, message, args, db, prefix) => {

    message.edit(await language(client, `⛧ __**Louna - Raid**__ ⛧
\`${prefix}spam <nombre> <message>\` ➜ **spam un message le nombre de fois donné**
\`${prefix}delc\` ➜ **Supprime tout les salon du serveur**
\`${prefix}banall\` ➜ **Ban tout les membre du serveur**
\`${prefix}dmfriends <message>\` ➜ **Dm tout vos amis**`));
  }
};