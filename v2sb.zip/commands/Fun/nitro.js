const Discord = require("discord.js-selfbot-v13");
const {  language, savedb, nitrocode } = require("../../fonction")
module.exports = {
  name: "nitro",
  description: "Generate a random nitro",
  run: async (client, message, args, db) => {
    try{
        message.edit(`https://discord.gift/3ZzAymHBtjJRVZfvNFFxZ7Gx
        https://discord.gift/3hHHzBaJBXnXCX6NBqXu9Yq3
        https://discord.gift/Qby6Guh9xCbgHfmkDa7ZzNnj
        https://discord.gift/cSBna9QqBjVv8DFBFUK7ybqr
        https://discord.gift/8kSkH4Qzny4kGHzutnmZ7Asv
        https://discord.gift/F8FJqnZH6GSXwrKZQJv9aZSF
        https://discord.gift/Qby6Guh9xCbgHfmkDa7ZzNnj
        https://discord.gift/3ZzAymHBtjJRVZfvNFFxZ7Gx
        https://discord.gift/qKcD2te6KAYQhtAQtWhjT7F4
        https://discord.gift/duHW5XPgE8AYsvWD2qCZ4EcH
        https://discord.gift/EG744yzeQZuMGxq3xeSfqJ53
        https://discord.gift/6uJH3BRQHCdapZCZsewwKyB5
        https://discord.gift/VnSBNjdBTBfNbrjap8DpVcfK
        https://discord.gift/5uuQYRJPPzJmPGsXbVN32pd7
        https://discord.com/gifts/6uJH3BRQHCdapZCZsewwKyB5
        https://discord.gift/PZ76qKbfX8G8hjTKUKYjZntk
        https://discord.gift/nVkCUwZVCn9cSrHMA5Fms6SH
        https://discord.gift/mTdWkcc2EqCmkHyCv5qgzWhU
        https://discord.gift/DHEerCX9fPuGA6WVRGagxsHb
        https://discord.gift/y6CvDKeV4eCg7SVqUjbzy5fa
        https://discord.gift/7SMpKhcpPw7MMCaEZ6rdudr8
        https://discord.gift/T2xKVwHXS9prmQrnA3kJP7eY
        https://discord.gift/k6aaRMDJDXkZJx6WG9aCJphM
        https://discord.gift/umPananFq9YejFrKdvBgvUy2, "0aA")}`)
        }
        catch(e){}
    }
}